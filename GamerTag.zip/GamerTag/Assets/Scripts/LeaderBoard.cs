using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class LeaderBoard : MonoBehaviour
{
    AskSystem askScript;
    MainMenu mainMenu;

    [SerializeField] GameObject group;
    [SerializeField] List<float> names;
    [SerializeField] List<string> scores;
    [SerializeField] List<float> times;

    bool stop;

    void Start()
    {
        askScript = FindObjectOfType<AskSystem>();
        mainMenu = FindObjectOfType<MainMenu>();

        //for (int i = 0; i < group.transform.childCount; i++)
        //{
        //    Record currentElement = group.transform.GetChild(i).GetComponent<Record>();
        //    if(currentElement.myScore )
        //}

        //for (int i = 0; i < transform.childCount; i++)
        //{
        //    if (stop)
        //        return;

        //    for (int j = 0; j < transform.GetChild(i).transform.childCount; j++)
        //    {
        //        if (transform.GetChild(i).transform.GetChild(j).name == "Name")
        //        {
        //            if (transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text == "")
        //            {
        //                print("Enter");
        //                transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text = mainMenu.name;
        //                stop = true;
        //                break;
        //            }
        //        }

        //        if (transform.GetChild(i).transform.GetChild(j).name == "Score")
        //        {
        //            if (transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text == "")
        //            {
        //                print("Enter");
        //                transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text = askScript.score.ToString();
        //                stop = true;
        //                break;
        //            }
        //        }

        //        if (transform.GetChild(i).transform.GetChild(j).name == "Time")
        //        {
        //            if (transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text == "")
        //            {
        //                print("Enter");
        //                transform.GetChild(i).transform.GetChild(j).GetComponent<TMP_Text>().text = askScript.totalTime.ToString();
        //                stop = true;
        //                break;
        //            }
        //        }
        //    }
        //}

        //transform.GetChild(3).SetSiblingIndex(0);
    }
}
