using UnityEngine;
using TMPro;

public class MainMenu : MonoBehaviour
{
    public string name;
    [SerializeField] TMP_InputField username;

    [SerializeField] GameObject[] windows;

    public bool arabic;

    [SerializeField] TMP_Text[] en_Text,ar_Text;

    public void EnterUsername()
    {
        if (username.text == string.Empty)
            return;

        name = username.text;

        windows[0].SetActive(false);
        windows[1].SetActive(true);
    }

    public void ArabicLanguage()
    {
        for (int i = 0; i < en_Text.Length; i++)
        {
            if (arabic)
            {
                en_Text[i].gameObject.SetActive(false);
                ar_Text[i].gameObject.SetActive(true);
            }
            else
            {
                en_Text[i].gameObject.SetActive(true);
                ar_Text[i].gameObject.SetActive(false);
            }
            
        }
    }

    public void EngLanguage(bool eng)
    {
        if (eng)
        {
            arabic = false;
        }
        else
        {
            arabic = true;
        }
    }
}
