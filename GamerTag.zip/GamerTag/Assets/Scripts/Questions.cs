using UnityEngine;

[System.Serializable]
public class Questions
{

    [TextArea]
    public string question;
    public string option1, option2, option3, option4;
    public bool[] answers = new bool[4];

}
