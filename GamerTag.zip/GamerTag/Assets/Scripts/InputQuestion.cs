using System.Collections.Generic;
using UnityEngine;

public class InputQuestion : MonoBehaviour
{
    public List<Questions> questionSystem;
    public List<Questions> questionSystem2;
}
