using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SortingTest : MonoBehaviour
{
    [SerializeField] TMP_Text[] numText;
    [SerializeField] float[] numbers;
    [SerializeField] GameObject group;

    [SerializeField] List<float> num;

    private void Start()
    {
        for (int i = 0; i < numText.Length; i++)
        {
            numText[i].text = num[i].ToString();
        }
        
        num.Sort();
        num.Reverse();

        for (int i = 0; i < group.transform.childCount; i++)
        {
            for (int j = 0; j < num.Count; j++)
            {
                if(group.transform.GetChild(i).GetComponent<TMP_Text>().text == num[j].ToString())
                {
                    group.transform.GetChild(i).SetSiblingIndex(j);
                }
            }
        }
    }
}
