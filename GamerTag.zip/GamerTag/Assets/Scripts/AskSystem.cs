using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class AskSystem : MonoBehaviour
{

    [SerializeField] bool test;

    //[SerializeField] List<Questions> questionSystem;

    MainMenu mainMenu;
    InputQuestion inputScript;

    //[SerializeField] string[] question;
    //string questionText,a1,a2,a3,a4;

    [SerializeField] TMP_Text questText,ar_QuestText;
    [SerializeField] Button[] options,wrongAnswers;
    [SerializeField] TMP_Text[] ar_Options;
    int wrongIndex;
    public float score, totalTime;

    [SerializeField] int lifeNum;
    [SerializeField] Image[] lifes;
    [SerializeField] Image wrongAlarm;

    //timer
    [SerializeField] float startTime;
    float time;
    [SerializeField] Image timerFill;
    bool canTime;

    [SerializeField] GameObject[] windows;

    [SerializeField] GameObject currentRecord,recordGroup;

    [SerializeField] List<string> names;
    [SerializeField] List<float> scores;
    [SerializeField] List<float> times;

    [SerializeField] int savedListCount,questionNum;

    private void Awake()
    {
        //foreach (Questions q in questionSystem)
        //{
        //    q.question = question;
        //}

        //for (int i = 0; i < questionSystem.Count; i++)
        //{

        //}

        mainMenu = FindObjectOfType<MainMenu>();
        inputScript = FindObjectOfType<InputQuestion>();
    }

    private void Start()
    {
        time = startTime;

        //test
        if (test)
        {
            Next();
        }

        loadList();

        //if(recordGroup.transform.GetChild(10) != null)
        //{
        //    Destroy(recordGroup.transform.GetChild(10).GetComponent<GameObject>());
        //}
    }

    private void Update()
    {
        if (!canTime)
            return;

        if(time <= 0)
        {
            //lose
            Lose();
        }
        else
        {
            time -= Time.deltaTime;
            timerFill.fillAmount = time / startTime;
        }

        totalTime += Time.deltaTime;
    }

    public void Next()
    {
        if(questionNum >= 10)
        {
            score += 100;
            canTime = false;
            windows[0].SetActive(false);
            windows[2].SetActive(true);
            return;
        }

        

        if (mainMenu.arabic)
        {

            int randNum = Random.Range(0, inputScript.questionSystem2.Count);

            ar_Options[0].text = inputScript.questionSystem2[randNum].option1;
            ar_Options[1].text = inputScript.questionSystem2[randNum].option2;
            ar_Options[2].text = inputScript.questionSystem2[randNum].option3;
            ar_Options[3].text = inputScript.questionSystem2[randNum].option4;

            for (int i = 0; i < options.Length; i++)
            {
                if (inputScript.questionSystem2[randNum].answers[i])
                {
                    options[i].onClick.AddListener(CorrectAnswer);
                }
                else
                {
                    options[i].onClick.AddListener(WrongAnswer);
                    wrongAnswers[i] = options[i];
                }
            }

            ar_QuestText.text = inputScript.questionSystem2[randNum].question;
            inputScript.questionSystem2.Remove(inputScript.questionSystem2[randNum]);
        }
        else
        {

            int randNum = Random.Range(0, inputScript.questionSystem.Count);

            options[0].GetComponentInChildren<TMP_Text>().text = inputScript.questionSystem[randNum].option1;
            options[1].GetComponentInChildren<TMP_Text>().text = inputScript.questionSystem[randNum].option2;
            options[2].GetComponentInChildren<TMP_Text>().text = inputScript.questionSystem[randNum].option3;
            options[3].GetComponentInChildren<TMP_Text>().text = inputScript.questionSystem[randNum].option4;

            for (int i = 0; i < options.Length; i++)
            {
                if (inputScript.questionSystem[randNum].answers[i])
                {
                    options[i].onClick.AddListener(CorrectAnswer);
                }
                else
                {
                    options[i].onClick.AddListener(WrongAnswer);
                    wrongAnswers[i] = options[i];
                }
            }

            questText.text = inputScript.questionSystem[randNum].question;
            inputScript.questionSystem.Remove(inputScript.questionSystem[randNum]);
        }

        time = startTime;
        canTime = true;
    }

    void CorrectAnswer()
    {
        print("correct");

        for (int i = 0; i < options.Length; i++)
        {
            options[i].onClick.RemoveAllListeners();

            if(wrongAnswers[i] != null)
            {
                wrongAnswers[i] = null;
                options[i].gameObject.SetActive(true);
            }
        }

        wrongIndex = 0;

        score += time;

        Next();
        questionNum++;
    }
    void WrongAnswer()
    {
        print("Wrong");

        lifes[lifeNum].color = new Color(255, 0, 0);
        lifeNum++;

        StartCoroutine(FadeOutAlaram());

        if (lifeNum == 3)
        {
            Lose();
        }
    }

    IEnumerator FadeOutAlaram()
    {
        wrongAlarm.gameObject.SetActive(true);
        Color c = wrongAlarm.color;

        for (float f = 0f; f <= 0.7f; f += 0.01f)
        {
            c.a = f;
            wrongAlarm.color = c;
            yield return new WaitForSeconds(0.003f);
        }

        StartCoroutine(FadeInAlaram());
    }

    IEnumerator FadeInAlaram()
    {
        Color c = wrongAlarm.color;

        for (float f = 0.7f; f >= 0.05f; f -= 0.01f)
        {
            c.a = f;
            wrongAlarm.color = c;
            yield return new WaitForSeconds(0.01f);
        }

        wrongAlarm.gameObject.SetActive(false);
    }

    IEnumerator Wrong()
    {
        //change color to red
        yield return new WaitForSeconds(0.5f);
        //get back normal
    }

    void Lose()
    {
        canTime = false;
        windows[0].SetActive(false);
        windows[1].SetActive(true);
    }

    public void Help(Button helpButton)
    {
        for (int i = 0; i < wrongAnswers.Length; i++)
        {
            if(wrongAnswers[i] != null && wrongIndex < 2)
            {
                wrongIndex++;
                wrongAnswers[i].gameObject.SetActive(false);
            }
        }

        helpButton.interactable = false;
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void NewRecord()
    {
        SortList();

        if (savedListCount >= 10)
        {
            if (score <= scores[9])
            {
                return;
            }
            else
            {
                names.Remove(names[9]);
                scores.Remove(scores[9]);
                times.Remove(times[9]);
                //Destroy(recordGroup.transform.GetChild(9).GetComponent<GameObject>());
            }
        }

        names.Add(mainMenu.name);
        scores.Add(score);
        times.Add(totalTime);

        GameObject recordRef = Instantiate(currentRecord, recordGroup.transform.position, Quaternion.identity, recordGroup.transform);
        recordRef.GetComponent<Record>().NewRecord(mainMenu.name, score, totalTime);

        for (int i = 0; i < names.Count; i++)
        {
            PlayerPrefs.SetString("Player" + i, names[i]);
            PlayerPrefs.SetFloat("Score" + i, scores[i]);
            PlayerPrefs.SetFloat("Time" + i, times[i]);
        }

        PlayerPrefs.SetInt("Count", names.Count);

        SortList();
    }

    public void loadList()
    {
        names.Clear();
        scores.Clear();
        times.Clear();
        savedListCount = PlayerPrefs.GetInt("Count");

        for (int i = 0; i < savedListCount; i++)
        {
            string player = PlayerPrefs.GetString("Player" + i);
            float sScore = PlayerPrefs.GetFloat("Score" + i);
            float tTime = PlayerPrefs.GetFloat("Time" + i);

            GameObject recordRef = Instantiate(currentRecord, recordGroup.transform.position, Quaternion.identity, recordGroup.transform);
            recordRef.GetComponent<Record>().NewRecord(player, sScore, tTime);

            names.Add(player);
            scores.Add(sScore);
            times.Add(tTime);
        }
    }

    void SortList()
    {
        scores.Sort();
        scores.Reverse();

        for (int i = 0; i < recordGroup.transform.childCount; i++)
        {
            for (int j = 0; j < scores.Count; j++)
            {
                if (recordGroup.transform.GetChild(i).transform.Find("Score").GetComponent<TMP_Text>().text == scores[j].ToString())
                {
                    recordGroup.transform.GetChild(i).SetSiblingIndex(j);
                }
            }
        }
    }

    //public void AR_QuestText()
    //{
    //    ar_QuestText.text = inputScript.questionSystem2[0].question;

    //    ar_Options[0].text = inputScript.questionSystem2[0].option1;
    //    ar_Options[1].text = inputScript.questionSystem2[0].option2;
    //    ar_Options[2].text = inputScript.questionSystem2[0].option3;
    //    ar_Options[3].text = inputScript.questionSystem2[0].option4;
    //}
}
