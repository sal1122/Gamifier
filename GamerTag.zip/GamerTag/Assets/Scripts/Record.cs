using System.Collections.Generic;
using System;
using UnityEngine;
using TMPro;

public class Record : MonoBehaviour
{
    [SerializeField] TMP_Text newName, score, time;
    public float myScore;
    [SerializeField] GameObject group;

    public void NewRecord(string nName, float nScore, float nTime)
    {
        
        //name
        newName.text = nName;
        //score
        score.text = nScore.ToString();
        //time in time format
        TimeSpan timeSpan = TimeSpan.FromSeconds(nTime);
        time.text = string.Format("{0:D2}:{1:D2}:{2:D2}", timeSpan.Minutes, timeSpan.Seconds, timeSpan.Milliseconds);
    }
}
