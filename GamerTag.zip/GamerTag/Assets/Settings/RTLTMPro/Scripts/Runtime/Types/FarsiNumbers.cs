﻿namespace RTLTMPro
{
    public enum FarsiNumbers
    {
        Zero = 0x6F0,
        One = 0x6F1,
        Two = 0x6F2,
        Three = 0x6F3,
        Four = 0x6F4,
        Five = 0x6F5,
        Six = 0x6F6,
        Seven = 0x6F7,
        Eight = 0x6F8,
        Nine = 0x6F9
    }
}