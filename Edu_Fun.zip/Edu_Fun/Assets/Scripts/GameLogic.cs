using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameLogic : MonoBehaviour
{
    //refs
    AudioSource myAudio;
    [SerializeField] AudioClip[] sounds;
    CameraShake camShake;

    //main
    [SerializeField] Image mainShape,fillShape;
    [SerializeField] Animator shapeAnim;
    [SerializeField] Sprite[] shapes,shapeFillSprite;
    int randShape,previousNum;
    bool select,win;
    Vector3 changeScale;
    [SerializeField] float startTimer,speed;
    float timer;

    //mobile
    Touch theTouch;
    Vector2 touchPos;
    Vector2 worldPos;

    //Effects
    [SerializeField] GameObject touchPar;
    [SerializeField] GameObject[] winPar;
    int parNumber;

    //Info
    int point;
    [SerializeField] TMP_Text pointTxt;
    [SerializeField] Text txtInfo;
    [SerializeField] Image timerFill;
    [SerializeField] string[] winTxt, loseTxt;

    private void Start()
    {
        myAudio = GetComponent<AudioSource>();
        camShake = GetComponent<CameraShake>();

        randShape = Random.Range(0, shapes.Length);
        previousNum = randShape;
        mainShape.sprite = shapes[randShape];

        changeScale = new Vector3(0.01f, 0.01f, 0);

        timer = startTimer;
    }

    private void Update()
    {
        //for mobile
        if(Input.touchCount > 0)
        {
            touchPos = theTouch.position;
            Instantiate(touchPar, touchPos, Quaternion.identity);
            myAudio.PlayOneShot(sounds[0]);
        }

        ////for pc
        //if (Input.GetMouseButtonDown(0))
        //{
        //    touchPos = Input.mousePosition;
        //    worldPos = Camera.main.ScreenToWorldPoint(touchPos);
        //    Instantiate(touchPar, worldPos, Quaternion.identity);
        //    myAudio.PlayOneShot(sounds[0]);
        //}

        if (timer <= 0)
        {
            Lose();

            fillShape.transform.localScale = new Vector3(0, 0, 0);
            select = false;
        }
        else
        {
            timer -= Time.deltaTime;
            timerFill.fillAmount = timer / startTimer;
        }

        if (select)
        {

            if (fillShape.transform.localScale.x < 2)
            {
                fillShape.transform.localScale += changeScale * Time.deltaTime * speed;
            }
            else
            {
                if (win)
                {
                    Win();
                }
                else
                {
                    Lose();
                }

                fillShape.transform.localScale = new Vector3(0, 0, 0);
                select = false;
            }
        }
    }

    public void SelectShape(int shapeNumber)
    {
        if (select)
        {
            return;
        }

        fillShape.sprite = shapeFillSprite[shapeNumber];
        parNumber = shapeNumber;

        if (randShape == shapeNumber)
        {
            print("Yaaay");
            win = true;
        }
        else
        {
            print("Try again!");
            win = false;
        }

        select = true;
    }

    void NextQuestion()
    {

        timer = startTimer;

        previousNum = randShape;

        randShape = Random.Range(0, shapes.Length);

        for (int i = 0; i < 100; i++)
        {
            if(randShape == previousNum)
            {
                randShape = Random.Range(0, shapes.Length);
            }
            else
            {
                break;
            }
        }
        
        mainShape.sprite = shapes[randShape];

        select = true;
    }

    void AddPar(int parNum)
    {
        switch (parNum)
        {
            case 0:

                Instantiate(winPar[0], new Vector2(0, 0), Quaternion.identity);

                break;

            case 1:

                Instantiate(winPar[1], new Vector2(0, 0), Quaternion.identity);

                break;

            case 2:

                Instantiate(winPar[2], new Vector2(0, 0), Quaternion.identity);

                break;
        }
    }

    void Win()
    {
        myAudio.PlayOneShot(sounds[1]);
        AddPar(parNumber);
        NextQuestion();

        point++;
        pointTxt.text = point.ToString();

        camShake.Shake(0.07f, 0.5f, 2);

        int randTxt = Random.Range(0, winTxt.Length);
        txtInfo.text = winTxt[randTxt];
    }
    void Lose()
    {
        myAudio.PlayOneShot(sounds[2]);
        NextQuestion();
        shapeAnim.SetTrigger("Lose");
        if (point > 0)
        {
            point--;
            pointTxt.text = point.ToString();
        }

        camShake.Shake(0.1f, 0.5f, 2);

        int randTxt = Random.Range(0, loseTxt.Length);
        txtInfo.text = loseTxt[randTxt];
    }
}
