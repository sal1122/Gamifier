using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManger : MonoBehaviour
{
    [SerializeField] int requiredAtoms;
    [SerializeField] int currentAtoms;
    [SerializeField] ParticleSystem particle;
    [SerializeField] float particalLifeTime;
    [SerializeField] Color[] atomColor;
    [SerializeField] GameObject[] atoms;

    //aduio setting
    //[SerializeField] GameObject audioManager;
    AudioManager2 audioManager2;

    // to make sure no win and lose happining in same time
    StepsCounterSystem stepsCounterSystem;

    //Shake
    CameraShake camShake;

    //wi/lose
    WinLoseCanvas winLose;

    //to handle the statement when the player reaches zero steps and has reached to the goal point
    public bool IsWon;

    private void Awake()
    {
        LeanTween.reset();
    }

    // Start is called before the first frame update
    void Start()
    {
        IsWon = false;
        currentAtoms = 0;
        camShake = FindObjectOfType<CameraShake>();
        winLose = FindObjectOfType<WinLoseCanvas>();
        stepsCounterSystem = FindObjectOfType<StepsCounterSystem>();
        //audioManager = GameObject.Find("AudioManger");
        audioManager2 = FindObjectOfType<AudioManager2>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("happend");
        if (collision.CompareTag("req"))
        {

            for (int i = 0; i < atoms.Length; i++)
            {
                if (collision.gameObject.name == atoms[i].name)
                {
                    particle.startColor = atomColor[i];
                }
            }
            camShake.Shake(0.07f, 0.5f, 2);
            currentAtoms++;
            audioManager2.Play("Explosion");
            StartCoroutine(StartPartical());
            collision.gameObject.SetActive(false);

            if(stepsCounterSystem.availableSteps >= 1 && currentAtoms < requiredAtoms)
            {
                Debug.Log("more than 1");
                stepsCounterSystem.AddStep();
                stepsCounterSystem.IsMoving = false;
                
            }
            else //esle if (stepsCounterSystem.availableSteps == 1 && currentAtoms == requiredAtoms)
            {
                stepsCounterSystem.GoalReached();
            }
            if (currentAtoms >= requiredAtoms)
            {
              
                //do somthing
                Debug.Log("YOU WON!!!");
                winLose.Win();
            }
          
        } else if (collision.CompareTag("nonReq") || collision.CompareTag("nonReqC"))
        {
            for (int i = 0; i < atoms.Length; i++)
            {
                if (collision.gameObject.name == atoms[i].name)
                {
                    particle.startColor = atomColor[i];
                }
            }
            camShake.Shake(0.07f, 0.5f, 2);
            collision.gameObject.SetActive(false);
            audioManager2.Play("Explosion2");
            StartCoroutine(StartPartical());
            stepsCounterSystem.GoalReached();
            Debug.Log("YOU LOST");
            winLose.Lose();
        }
    }


    IEnumerator StartPartical()
    {
        particle.Play();
        yield return new WaitForSeconds(particalLifeTime);
        particle.Stop();

    }

}
