using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGVolController : MonoBehaviour
{

    
    AudioSource BGAudio;
    BGSoundScript BGMusic;

    [Range(0, 1)]
    [SerializeField] float maxVolume;
    [Range(0, 1)]
    [SerializeField] float minVolume;
    [SerializeField] float speed;

    public bool keepFadeIn;
    public bool keepFadeOut;

    // Start is called before the first frame update
    void Start()
    {
        BGMusic = FindObjectOfType<BGSoundScript>();
        BGAudio = BGMusic.GetComponent<AudioSource>();
        StartFadeOut();
    }


    public void StartFadeIn()
    {
        StartCoroutine(FadeIn());
    }

    IEnumerator FadeIn( )
    {
        keepFadeIn = true;
        keepFadeOut = false;

        while(BGAudio.volume < maxVolume && keepFadeIn)
        {
            BGAudio.volume += speed;
            yield return new WaitForSecondsRealtime(0.1f);
        }
    }


    public void StartFadeOut()
    {
        StartCoroutine(FadeOut());
    }

    IEnumerator FadeOut()
    {
        keepFadeIn = false;
        keepFadeOut = true;

        while (BGAudio.volume > minVolume && keepFadeOut)
        {
            BGAudio.volume -= speed;
            yield return new WaitForSecondsRealtime(0.1f);
        }
    }
}
