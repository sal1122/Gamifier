using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReactionAgent : MonoBehaviour
{
 
    [SerializeField] ParticleSystem particle;
    [SerializeField] float particalLifeTime;
  

    //aduio setting
    //[SerializeField] GameObject audioManager;
    AudioManager2 audioManager2;

    // to make sure no win and lose happining in same time
    StepsCounterSystem stepsCounterSystem;

    //Shake
    CameraShake camShake;

    //wi/lose
    WinLoseCanvas winLose;


    private void Awake()
    {
        LeanTween.reset();
    }

    // Start is called before the first frame update
    void Start()
    {
        camShake = FindObjectOfType<CameraShake>();
        winLose = FindObjectOfType<WinLoseCanvas>();
        stepsCounterSystem = FindObjectOfType<StepsCounterSystem>();
        audioManager2 = FindObjectOfType<AudioManager2>();
    }

    // Update is called once per frame
    void Update()
    {

    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("happend");
        if (collision.CompareTag("nonReqC"))
        {
            camShake.Shake(0.07f, 0.5f, 2);
            collision.gameObject.SetActive(false);
            audioManager2.Play("Explosion");
            stepsCounterSystem.AddStep();
            stepsCounterSystem.IsMoving = false;
            StartCoroutine(StartPartical());
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
            gameObject.GetComponent<Collider2D>().enabled = false;




        }
        else if (collision.CompareTag("req") || collision.CompareTag("nonReq"))
        {

           

            camShake.Shake(0.07f, 0.5f, 2);
            audioManager2.Play("Explosion2");
            StartCoroutine(StartPartical());
            collision.gameObject.SetActive(false);
            stepsCounterSystem.GoalReached();
            winLose.Lose();
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
            gameObject.GetComponent<Collider2D>().enabled = false;


        }
    }


    IEnumerator StartPartical()
    {
        particle.Play();
        yield return new WaitForSeconds(particalLifeTime);
        particle.Stop();
        Destroy(gameObject);


    }


}
