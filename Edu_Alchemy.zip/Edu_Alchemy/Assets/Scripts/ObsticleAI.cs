using System.Collections;
using UnityEngine;

public class ObsticleAI : MonoBehaviour
{

    Rigidbody2D rb;
    DialogueSystem ds;
    SpriteRenderer sr;

    [SerializeField] Sprite[] arrowDirection;

    [SerializeField] float speed,waitTime;
    bool up = true, right, stop, startDetect;

    enum Direction { horizontal,vectical };
    [SerializeField] Direction direction;


   

    private void Start()
    {

        rb = GetComponent<Rigidbody2D>();
        ds = FindObjectOfType<DialogueSystem>();
        sr = GetComponent<SpriteRenderer>();

        switch (direction)
        {
            case Direction.horizontal:

                right = true;
                sr.sprite = arrowDirection[0];

                break;

            case Direction.vectical:

                right = false;
                sr.sprite = arrowDirection[1];

                break;
        }
    }

    void FixedUpdate()
    {
        if (stop || !ds.finished)
            return;

        startDetect = true;

        if (!right)
        {
            if (up)
            {
                rb.velocity = new Vector2(rb.velocity.x, speed);
                sr.flipY = false;
            }
            else
            {
                rb.velocity = new Vector2(rb.velocity.x, -speed);
                sr.flipY = true;
            }
        }
        else
        {
            if (up)
            {
                rb.velocity = new Vector2(speed, rb.velocity.y);
                sr.flipX = false;
            }
            else
            {
                rb.velocity = new Vector2(-speed, rb.velocity.y);
                sr.flipX = true;
            }
        }


    }

    void OnCollisionEnter2D(Collision2D col)
    {
        
        if (!startDetect)
            return;

        if (col.gameObject.tag == ("Wall"))
        {
            if (up)
            {
                up = false;
            }
            else
            {
                up = true;
            }

            StartCoroutine(Move());
        
        }
        
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("req") || col.CompareTag("nonReq") || col.CompareTag("nonReqC"))
        {
            col.gameObject.GetComponent<PlayerController>().ResetPos();
        }
    }

    IEnumerator Move()
    {
        rb.velocity = Vector2.zero;
        stop = true;
        yield return new WaitForSeconds(waitTime);
        stop = false;
    }


}
