using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class UIManager : MonoBehaviour
{
    [SerializeField] GameObject book;
    [SerializeField] Button bookImg;
    [SerializeField] Canvas gamePlayCanvas;
    bool open;

    DialogueSystem ds;
    [SerializeField] Sprite[] bookSprite;

    bool doOnce;

    public Transform box;

    private void Awake()
    {
        LeanTween.reset();
    }

    private void Start()
    {
        doOnce = true;
        ds = FindObjectOfType<DialogueSystem>();
        bookImg.interactable = false;
        box.localScale = Vector2.zero;
    }


    // to make the book shaded when it can't be pressed
    private void Update()
    {
        if (doOnce == true)
        {
            if (ds.finished == true)
            {
               bookImg.interactable = true;
                doOnce = false;
            }

        }
    }

    public void Book()
    {
        if (!ds.finished)
            return;

        if (open)
        {
            Time.timeScale = 1;
            //book.SetActive(false);
            box.LeanScale(Vector2.zero, 0.4f).setEaseInBack().setOnComplete(OnComplete);
            bookImg.GetComponent<Image>().sprite = bookSprite[0];
            //gamePlayCanvas.enabled = true;
            open = false;
        }
        else
        {
            Time.timeScale = 0;
            book.SetActive(true);
            box.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack();//.delay = 0.3f;
            bookImg.GetComponent<Image>().sprite = bookSprite[1];
            StartCoroutine(Waiting());
            gamePlayCanvas.enabled = false;
            open = true;
        }
    }

    void OnComplete()
    {
        Debug.Log("close the book");
    }

    public void NextScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    IEnumerator Waiting()
    {
        yield return new WaitForSeconds(0.5f);
        gamePlayCanvas.enabled = true;
    }
}
