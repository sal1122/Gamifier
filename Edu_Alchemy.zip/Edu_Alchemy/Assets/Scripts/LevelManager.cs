using UnityEngine;
using UnityEngine.UI;

public class LevelManager : MonoBehaviour
{
    //the number of levels unlocked
    int levelUnlocked;

    //Level Objects
    [SerializeField] GameObject[] levelObject,books;

    //should contain two sprites in the same order (close book,open book)
    [SerializeField] Sprite[] levelSprite;

    void Start()
    {
        //save number of level unlocked
        levelUnlocked = PlayerPrefs.GetInt("levelUnlocked", 1);

        //lock all levels
        for (int i = 0; i < levelObject.Length; i++)
        {
            levelObject[i].GetComponent<Image>().sprite = levelSprite[0];
            levelObject[i].GetComponent<Button>().interactable = false;
            books[i].GetComponent<Button>().interactable = false;
        }

        //unlock some levels
        for (int i = 0; i < levelUnlocked; i++)
        {
            levelObject[i].GetComponent<Image>().sprite = levelSprite[1];
            levelObject[i].GetComponent<Button>().interactable = true;
            books[i].GetComponent<Button>().interactable = true;
        }
    }

    public void ResetPlayerPref()
    {
        PlayerPrefs.DeleteAll();
    }
}
