using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextBlinkingEffect : MonoBehaviour
{
    [SerializeField] float timeOffset;
    [SerializeField] float repeatRate;
    [SerializeField] GameObject textImage;
    [SerializeField] float waitTime;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("blinkingAnimation", timeOffset, repeatRate);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void blinkingAnimation()
    {
        StartCoroutine(Fade());
    }

    IEnumerator Fade()
    {
        textImage.SetActive(false);
        yield return new WaitForSecondsRealtime(waitTime);
        textImage.SetActive(true);
    }
}
