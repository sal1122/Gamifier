using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseButton : MonoBehaviour
{
    // to make sure that you can not pause the game until the dialogue is finished
    DialogueSystem ds;

    [SerializeField] Button pauseButton;
    bool doOnce;
    // Start is called before the first frame update
    void Start()
    {
        doOnce = true;
        ds = FindObjectOfType<DialogueSystem>();
        pauseButton.interactable = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (doOnce == true)
        {
            if(ds.finished == true)
            {
                pauseButton.interactable = true;
                doOnce = false;
            }
            
        }
    }
}
