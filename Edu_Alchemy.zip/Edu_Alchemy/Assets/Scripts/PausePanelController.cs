using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PausePanelController : MonoBehaviour
{

    private Vector2 startTouchPosition;
    private Vector2 currentPosition;
    private Vector2 endTouchPosition;
    private bool stopTouch = false;
    public float tapRange;
    WinLoseCanvas winLoseCanvas;
    // Start is called before the first frame update
    void Start()
    {
        winLoseCanvas = FindObjectOfType<WinLoseCanvas>();
    }

    // Update is called once per frame
    void Update()
    {
        Tab();
    }


    void Tab()
    {

        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            startTouchPosition = Input.GetTouch(0).position;
        }


        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)
        {
            stopTouch = false;

            endTouchPosition = Input.GetTouch(0).position;

            Vector2 Distance = endTouchPosition - startTouchPosition;

            if (Mathf.Abs(Distance.x) < tapRange && Mathf.Abs(Distance.y) < tapRange)
            {
                Debug.Log("TapPause");
                Time.timeScale = 1;
                winLoseCanvas.CloseDialog();

            }

        }
    }
}
