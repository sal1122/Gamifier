using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartBtn : MonoBehaviour
{
    public Animator anim;

    public void LoadNextLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex + 1));
    }

    public void LoadPreviousLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex - 1));
    }

    public void GoLevelScene()
    {
        StartCoroutine(LoadLevel(1));
    }

    public void GoLevel1()
    {
        StartCoroutine(LoadLevel(2));
    }

    public void GoLevel2()
    {
        StartCoroutine(LoadLevel(3));
    }

    public void GoLevel3()
    {
        StartCoroutine(LoadLevel(4));
    }

    public void GoLevel4()
    {
        StartCoroutine(LoadLevel(5));
    }

    public void GoLevel5()
    {
        StartCoroutine(LoadLevel(6));
    }

    public void GoLevel6()
    {
        StartCoroutine(LoadLevel(7));
    }

    public void GoLevel7()
    {
        StartCoroutine(LoadLevel(8));
    }

    public void GoLevel8()
    {
        StartCoroutine(LoadLevel(9));
    }

    IEnumerator LoadLevel(int levelIndex)
    {
        Time.timeScale = 1;
        anim.SetTrigger("Start");
        yield return new WaitForSeconds(0.7f);
        SceneManager.LoadScene(levelIndex);
    }


    public void QuitGame()
    {
        Application.Quit();
    }
}
