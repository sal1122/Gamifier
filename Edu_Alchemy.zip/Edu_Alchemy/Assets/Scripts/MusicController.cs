using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicController : MonoBehaviour
{
    BGSoundScript backGroundMusic;
    [SerializeField] Sprite[] SoundSprites;
    AudioSource audioSource;


    private void Awake()
    {
        
       
    }

    // Start is called before the first frame update
    void Start()
    {
        backGroundMusic = FindObjectOfType<BGSoundScript>();
        audioSource = backGroundMusic.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (audioSource.isPlaying)
        {
            GetComponent<Image>().sprite = SoundSprites[0];
        }
        else
        {
            GetComponent<Image>().sprite = SoundSprites[1];
        }
    }

    public void PlayPauseMusic()
    {
        if (backGroundMusic.IsMusicOn)
        {
            audioSource.Pause();
            backGroundMusic.IsMusicOn = false;
        }
        else
        {
            audioSource.Play();
            backGroundMusic.IsMusicOn = true;
        }

    }
}
