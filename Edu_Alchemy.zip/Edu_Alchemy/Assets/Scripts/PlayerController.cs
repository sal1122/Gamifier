﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Transform movePoint;
    public LayerMask whatStopsMovement;

    //moving obstacle setting
    public Vector3 atomStartPos;
    public Vector3 movePointStartPos;



    //these variables for detecting taps and swipes
    private Vector2 startTouchPosition;
    private Vector2 currentPosition;
    private Vector2 endTouchPosition;
    private bool stopTouch = false;
    public float swipeRange;
    public float tapRange;


    //aduio setting
    //[SerializeField] GameObject audioManager;

    //selcting object
    [SerializeField] bool IsSlected;

    //steps counting 
    public GameObject gameManger;
    private bool addOnce;
    private bool playSwipeOnce;

    Vector2 moveDirection;

    public bool move,stop,spriteMove;

    //Shake
    CameraShake camShake;
    bool canShake;

    DialogueSystem ds;
    AudioManager2 audioManager2;

    public Transform[] portPos;

    void Start()
    {
        atomStartPos = gameObject.GetComponent<Transform>().position;
        movePointStartPos = movePoint.GetComponent<Transform>().position;
        addOnce = false;
        playSwipeOnce = false;
        movePoint.parent = null;
        IsSlected = false;
        gameManger =  GameObject.Find("Game Manger");

        //audioManager = GameObject.Find("AudioManger");
        camShake = FindObjectOfType<CameraShake>();
        ds = FindObjectOfType<DialogueSystem>();
        audioManager2 = FindObjectOfType<AudioManager2>();
    }

    void Update()
    {
        if (!ds.finished)
            return;

        if(portPos[0] == null && portPos[1] == null)
        {
            transform.position = Vector2.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
        }
        else
        {
            if(portPos[0] != null)
            {
                transform.position = Vector2.MoveTowards(transform.position, portPos[0].position, moveSpeed * Time.deltaTime);
            }
            else
            {
                transform.position = Vector2.MoveTowards(transform.position, portPos[1].position, moveSpeed * Time.deltaTime);
            }
        }
        
        if (Vector2.Distance(transform.position, movePoint.position) <= 0.05f && canShake)
        {
            if (addOnce)
            {
               gameManger.GetComponent<StepsCounterSystem>().AddStep2();
                addOnce = false;
            }
            audioManager2.Play("Impact");
            camShake.Shake(0.01f, 0.02f, 1);
            canShake = false;
            stop = false;

            // to make sure no movments happen when losing or winning 
            if(gameManger.GetComponent<StepsCounterSystem>().availableSteps > 0)
            {
                gameManger.GetComponent<StepsCounterSystem>().IsMoving = false;
            }
           
            //if(portPos != null)
            //{
            //    movePoint.transform.position = portPos.position;
            //}
        }

        Swipe();
    }

    private void FixedUpdate()
    {
        if (move)
        {
                Move();
        }
    }

    public void Swipe()
    {
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            startTouchPosition = Input.GetTouch(0).position;
        }

        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved)
        {
            currentPosition = Input.GetTouch(0).position;
            Vector2 Distance = currentPosition - startTouchPosition;

            if (!stopTouch)
            {

                if (Distance.x < -swipeRange)
                {
                    Debug.Log("Left");
                    if (IsSlected == true && Time.timeScale ==1)
                    {
                        if (gameManger.GetComponent<StepsCounterSystem>().IsMoving == false)
                        {
                            gameManger.GetComponent<StepsCounterSystem>().IsMoving = true;
                            moveDirection.x = -1;
                            moveDirection.y = 0;
                            move = true;
                            playSwipeOnce = true;
                        }
                      
                    }

                    stopTouch = true;
                    gameManger.GetComponent<StepsCounterSystem>().direction = StepsCounterSystem.Direction.left;
                }
                else if (Distance.x > swipeRange)
                {
                    Debug.Log("Right");
                    if (IsSlected == true && Time.timeScale == 1)
                    {
                        if(gameManger.GetComponent<StepsCounterSystem>().IsMoving == false)
                        {
                            gameManger.GetComponent<StepsCounterSystem>().IsMoving = true;
                            moveDirection.x = 1;
                            moveDirection.y = 0;
                            move = true;
                            playSwipeOnce = true;
                        }
                       

                    }

                    stopTouch = true;
                    gameManger.GetComponent<StepsCounterSystem>().direction = StepsCounterSystem.Direction.right;
                }
                else if (Distance.y > swipeRange)
                {
                    Debug.Log("Up");
                    if (IsSlected == true && Time.timeScale == 1)
                    {
                        if(gameManger.GetComponent<StepsCounterSystem>().IsMoving == false)
                        {
                            gameManger.GetComponent<StepsCounterSystem>().IsMoving = true;
                            moveDirection.x = 0;
                            moveDirection.y = 1;
                            move = true;
                            playSwipeOnce = true;
                        }
                      

                    }

                    stopTouch = true;
                    gameManger.GetComponent<StepsCounterSystem>().direction = StepsCounterSystem.Direction.up;
                }
                else if (Distance.y < -swipeRange)
                {
                    Debug.Log("Down");
                    if (IsSlected == true && Time.timeScale == 1)
                    {
                        if(gameManger.GetComponent<StepsCounterSystem>().IsMoving == false)
                        {
                            gameManger.GetComponent<StepsCounterSystem>().IsMoving = true;
                            moveDirection.x = 0;
                            moveDirection.y = -1;
                            move = true;
                            playSwipeOnce = true;
                        }
                       

                    }

                    stopTouch = true;
                    gameManger.GetComponent<StepsCounterSystem>().direction = StepsCounterSystem.Direction.down;
                }

            }

        }

        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)
        {
            stopTouch = false;

            endTouchPosition = Input.GetTouch(0).position;

            Vector2 Distance = endTouchPosition - startTouchPosition;

            if (Mathf.Abs(Distance.x) < tapRange && Mathf.Abs(Distance.y) < tapRange)
            {
                Debug.Log("Tap");
            }

        }


    }

    private void Move()
    {
        if (!Physics2D.OverlapCircle(movePoint.position + new Vector3(moveDirection.x, moveDirection.y, 0f), .2f, whatStopsMovement))
        {
            //if (stop)
            //    return;

            movePoint.position += new Vector3(moveDirection.x, moveDirection.y, -20f);
            //transform.Translate(new Vector2(moveDirection.x * moveSpeed * Time.deltaTime, moveDirection.y * moveSpeed * Time.deltaTime));
            //rb.velocity = new Vector2(moveDirection.x * moveSpeed, moveDirection.y * moveSpeed);
   
            addOnce = true;
            if(playSwipeOnce == true)
            {
                audioManager2.Play("Swipe");
                playSwipeOnce = false;
            }
        }
        else
        {
            move = false;
            spriteMove = true;
            canShake = true;
        }
    }

    //the flowing methods is for moving one object at time

    private void OnMouseDown()
    {
        Debug.Log("Selected");
        if(ds.finished == true)
        {
            if(Time.timeScale == 1)
            {
                if (gameManger.GetComponent<StepsCounterSystem>().IsMoving == false)
                {
                 
                   audioManager2.Play("Tab");
                   Debug.Log("tab allowed");
                    
                   
                }
                else
                {
                    Debug.Log("tab is not allowed");
                }
            }
            
        }
        
        IsSlected = true;
    }

    private void OnMouseUp()
    {
        Debug.Log("Deselected");
        IsSlected = false;
    }


    public void ResetPos()
    {
        portPos[0] = null;
        portPos[1] = null;
        StartCoroutine(DelayRestPos());
    }


    IEnumerator DelayRestPos()
    {
        gameObject.GetComponent<TrailRenderer>().enabled = false;
        transform.position = atomStartPos;
        audioManager2.Play("Impact");
        camShake.Shake(0.01f, 0.02f, 1);
        movePoint.GetComponent<Transform>().position = movePointStartPos;
        yield return new WaitForSeconds(0.5f);
        gameObject.GetComponent<TrailRenderer>().enabled = true;
    }

    public IEnumerator StopTrail(float waitTime)
    {
        gameObject.GetComponent<TrailRenderer>().enabled = false;
        yield return new WaitForSeconds(waitTime);
        gameObject.GetComponent<TrailRenderer>().enabled = true;
    }

    public void DeleteTemp()
    {
        if(portPos[0] != null)
        {
            portPos[0] = null;
        }
        else
        {
            portPos[1] = null;
        }
    }

}
