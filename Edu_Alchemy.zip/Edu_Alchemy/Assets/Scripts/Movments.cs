using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movments : MonoBehaviour
{
    //these variables for moving the object
    [SerializeField] Rigidbody2D rb;
    [SerializeField] Vector2 forceXAxis;
    [SerializeField] Vector2 forceYAxis;

    //these variables for detecting taps and swipes
    private Vector2 startTouchPosition;
    private Vector2 currentPosition;
    private Vector2 endTouchPosition;
    private bool stopTouch = false;
    public float swipeRange;
    public float tapRange;

    //these variables for detecting  Raycast Collisions
    [SerializeField] float originOffset;
    [SerializeField] float maxDistance;
    //placing the raycast
    [SerializeField] Transform ChildPos;

    //selcting object
    [SerializeField] bool IsSlected;

    //restricting movements
    [SerializeField] bool IsAllowedLeft, IsAllowedRight, IsAllowedUp, IsAllowedDown;
    [SerializeField] bool IsHitLeft, IsHitRight, IsHitUp, IsHitDown;

    private void Start()
    {
        IsHitLeft = false;
        IsHitRight = false;
        IsHitUp = false;
        IsHitDown = false;
        IsAllowedLeft = true;
        IsAllowedRight = true;
        IsAllowedUp = true;
        IsAllowedDown = true;
        IsSlected = false;
        rb = gameObject.GetComponent<Rigidbody2D>();

    }



    // Update is called once per frame
    void Update()
    {
        Swipe();

        CheckRaycastLeft();
        CheckRaycastRight();
        CheckRaycastUp();
        CheckRaycastDown();



    }

    public void Swipe()
    {
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            startTouchPosition = Input.GetTouch(0).position;
        }

        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved)
        {
            currentPosition = Input.GetTouch(0).position;
            Vector2 Distance = currentPosition - startTouchPosition;

            if (!stopTouch)
            {

                if (Distance.x < -swipeRange)
                {
                    Debug.Log("Left");
                    if (IsSlected == true && IsAllowedLeft == true && rb.velocity.magnitude < 0.1f)
                    {
                        rb.velocity = -(forceXAxis);
                    }

                    stopTouch = true;
                }
                else if (Distance.x > swipeRange)
                {
                    Debug.Log("Right");
                    if (IsSlected == true && IsAllowedRight == true && rb.velocity.magnitude < 0.1f)
                    {

                        rb.velocity = forceXAxis;
                    }

                    stopTouch = true;
                }
                else if (Distance.y > swipeRange)
                {
                    Debug.Log("Up");
                    if (IsSlected == true && IsAllowedUp == true && rb.velocity.magnitude < 0.1f)
                    {
                        rb.velocity = forceYAxis;
                    }

                    stopTouch = true;
                }
                else if (Distance.y < -swipeRange)
                {
                    Debug.Log("Down");
                    if (IsSlected == true && IsAllowedDown == true && rb.velocity.magnitude < 0.1f)
                    {
                        rb.velocity = -(forceYAxis);
                    }

                    stopTouch = true;
                }

            }

        }

        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)
        {
            stopTouch = false;

            endTouchPosition = Input.GetTouch(0).position;

            Vector2 Distance = endTouchPosition - startTouchPosition;

            if (Mathf.Abs(Distance.x) < tapRange && Mathf.Abs(Distance.y) < tapRange)
            {
                Debug.Log("Tap");
            }

        }


    }


    //the flowing methods is for moving one object at time

    private void OnMouseDown()
    {
        Debug.Log("Selected");
        IsSlected = true;
    }

    private void OnMouseUp()
    {
        Debug.Log("Deselected");
        IsSlected = false;
    }



    //the following methods is for detecting collisions in all directions
    private void CheckRaycastLeft()
    {
        RaycastHit2D hit = Physics2D.Raycast(new Vector2(ChildPos.position.x + -(originOffset), ChildPos.position.y), ChildPos.TransformDirection(Vector2.left), maxDistance);
        Debug.DrawRay(new Vector2(ChildPos.position.x + -(originOffset), ChildPos.position.y), ChildPos.TransformDirection(Vector2.left) * maxDistance, Color.red);


        if (hit)
        {


            if (IsHitLeft == false)
            {
                rb.velocity = new Vector2(0f, 0f);
                IsHitLeft = true;
            }
            IsAllowedLeft = false;

             Debug.Log("Hit Somthing : " + hit.collider.name);
        }
        else
        {

            IsAllowedLeft = true;
            IsHitLeft = false;
        }
    }


    private void CheckRaycastRight()
    {

        RaycastHit2D hit = Physics2D.Raycast(new Vector2(ChildPos.position.x + (originOffset), ChildPos.position.y), ChildPos.TransformDirection(Vector2.right), maxDistance);
        Debug.DrawRay(new Vector2(ChildPos.position.x + (originOffset), ChildPos.position.y), ChildPos.TransformDirection(Vector2.right) * maxDistance, Color.red);

        if (hit)
        {


            if (IsHitRight == false)
            {
                rb.velocity = new Vector2(0f, 0f);
                IsHitRight = true;
            }
            IsAllowedRight = false;

             Debug.Log("Hit Somthing : " + hit.collider.name);
        }
        else
        {
            IsAllowedRight = true;
            IsHitRight = false;
        }
    }

    private void CheckRaycastUp()
    {

        RaycastHit2D hit = Physics2D.Raycast(new Vector2(ChildPos.position.x, ChildPos.position.y + (originOffset)), ChildPos.TransformDirection(Vector2.up), maxDistance);
        Debug.DrawRay(new Vector2(ChildPos.position.x, ChildPos.position.y + (originOffset)), ChildPos.TransformDirection(Vector2.up) * maxDistance, Color.red);

        if (hit)
        {
            if (IsHitUp == false)
            {
                rb.velocity = new Vector2(0f, 0f);
                IsHitUp = true;
            }
            IsAllowedUp = false;
            Debug.Log("Hit Somthing : " + hit.collider.name);
        }
        else
        {
            IsAllowedUp = true;
            IsHitUp = false;

        }
    }


    private void CheckRaycastDown()
    {

        RaycastHit2D hit = Physics2D.Raycast(new Vector2(ChildPos.position.x, ChildPos.position.y + -(originOffset)), ChildPos.TransformDirection(Vector2.down), maxDistance);
        Debug.DrawRay(new Vector2(ChildPos.position.x, ChildPos.position.y + -(originOffset)), ChildPos.TransformDirection(Vector2.down) * maxDistance, Color.red);

        if (hit)
        {
            if (IsHitDown == false)
            {
                rb.velocity = new Vector2(0f, 0f);
                IsHitDown = true;
            }
            IsAllowedDown = false;
             Debug.Log("Hit Somthing : " + hit.collider.name);
        }
        else
        {
            IsAllowedDown = true;
            IsHitDown = false;
        }
    }

}
