using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WinLoseCanvas : MonoBehaviour
{
    // lose win contoller
    public GameObject winPanel;
    public GameObject losePanel;
    public float delayTime;
    public float delayTime2;

    public Transform boxW;
    public Transform boxL;
    //public CanvasGroup background;

    public Animator anim;

    //aduio setting
    AudioManager2 audioManager;
    //BG music conroller;
    BGVolController bGVolController;

    //save system 
    UnlockLevels unlockLevels;

    //StartBtn SBtnV;

    //int winORlose;
    private void Awake()
    {
        LeanTween.reset();
    }

    // Start is called before the first frame update
    void Start()
    {
        audioManager = FindObjectOfType<AudioManager2>();
        unlockLevels = FindObjectOfType<UnlockLevels>();
        bGVolController = FindObjectOfType<BGVolController>();
        boxW.localScale = Vector2.zero;
        boxL.localScale = Vector2.zero;
        //winPanel.SetActive(false);
        //losePanel.SetActive(false);
        //winPanel.transform.localScale = new Vector3(1, 1, 0);
        //losePanel.transform.localScale = new Vector3(1, 1, 0);

        //winORlose = 0;
        //winPanel.SetActive(false);
        //losePanel.SetActive(false);
    }

    /*// Update is called once per frame
    void Update()
    {
        
    }*/

    private void OnEnable()
    {
        //background.alpha = 0;
        //background.LeanAlpha(1, 0.5f);

        //box.localPosition = new Vector2(0, -Screen.height);
        //box.LeanMoveLocalY(0, 1.5f).setEaseOutExpo().delay = 0.1f;
        /*if(winORlose == 1)
            boxW.LeanScale(Vector2.one, 0.7f).setEaseOutBack().delay = 0.3f;
        else if(winORlose == 1)
            boxL.LeanScale(Vector2.one, 0.7f).setEaseOutBack().delay = 0.3f;*/
    }

    public void Win()
    {
        unlockLevels.Pass();
        StartCoroutine(Winning());
        //winORlose = 1;
    }

    public void Lose()
    {
        StartCoroutine(Losing());
        //winORlose = 2;
    }

    IEnumerator Winning()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime);

        audioManager.Play("Win");
        winPanel.SetActive(true);
        /*boxW.localPosition = new Vector2(0, -Screen.height);
        boxW.LeanMoveLocalY(0, 0.9f).setEaseOutExpo().delay = 0.1f;*/
        //boxW.LeanScale(Vector2.one, 0.7f).setEaseOutBack().setOnComplete(OnComplete).delay = 0.3f;
        Time.timeScale = 0;
        
        Debug.Log("Wining method: before");
        boxW.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        Debug.Log("Wining method: after");
        //winPanel.transform.localScale = new Vector3(1, 1, 0);
       yield return new WaitForSecondsRealtime(1f);
       bGVolController.StartFadeIn();
    }

    IEnumerator Losing()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime);
        
        audioManager.Play("Lose");
        losePanel.SetActive(true);
        /*boxL.localPosition = new Vector2(0, -Screen.height);
        boxL.LeanMoveLocalY(0, 0.9f).setEaseOutExpo().delay = 0.1f;*/
        Time.timeScale = 0;
        Debug.Log("Losing method: before");
        boxL.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        //boxL.LeanScale(Vector2.one, 0.7f).setEaseOutBack().delay = 0.3f;
        Debug.Log("Losing method: after leentween");
        //StartCoroutine(WaitingForSomething());
        //Debug.Log("Losing method: after coroutine");
        //losePanel.transform.localScale = new Vector3(1, 1, 0);
       yield return new WaitForSecondsRealtime(1f);
       bGVolController.StartFadeIn();
    }

    public void CloseDialog()
    {
        //boxL.LeanMoveLocalY(-Screen.height, 0.5f).setEaseInExpo().setOnComplete(OnComplete);
        boxL.LeanScale(Vector2.zero, 0.4f).setIgnoreTimeScale(true).setEaseInBack().setOnComplete(OnComplete);
        boxW.LeanScale(Vector2.zero, 0.4f).setIgnoreTimeScale(true).setEaseInBack().setOnComplete(OnComplete);
    }

    void OnComplete()
    {
        //gameObject.SetActive(false);
        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex));
    }

    /*IEnumerator WaitingForSomething()
    {
        yield return new WaitForSeconds(2);
        Debug.Log("done done !!!");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }*/

    /*public void RestartTheScene()
    {
        //transform.LeanScale(Vector2.zero, 0.4f).setEaseInBack();
        StartCoroutine(LoadLevel(2));
    }*/

    IEnumerator LoadLevel(int levelIndex)
    {
        Time.timeScale = 1;
        anim.SetTrigger("Start");
        yield return new WaitForSeconds(0.7f);
        SceneManager.LoadScene(levelIndex);
    }


    public void Lose2()
    {
        StartCoroutine(Losing2());
        //winORlose = 2;
    }

    IEnumerator Losing2()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime2);
        
        audioManager.Play("Lose");
        losePanel.SetActive(true);
        /*boxL.localPosition = new Vector2(0, -Screen.height);
        boxL.LeanMoveLocalY(0, 0.9f).setEaseOutExpo().delay = 0.1f;*/
        Time.timeScale = 0;
        Debug.Log("Losing method: before");
        boxL.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        //boxL.LeanScale(Vector2.one, 0.7f).setEaseOutBack().delay = 0.3f;
        Debug.Log("Losing method: after leentween");
        //StartCoroutine(WaitingForSomething());
        //Debug.Log("Losing method: after coroutine");
        //losePanel.transform.localScale = new Vector3(1, 1, 0);
        yield return new WaitForSecondsRealtime(1f);
        bGVolController.StartFadeIn();
    }
}
