using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StepsCounterSystem : MonoBehaviour
{

    [SerializeField] int alarmStepsNum;
    public int availableSteps;
    public int usedSteps;
    public GameObject stepsCounterText;
    GameManger gameManger;

    //to make 1 atom move at a time
    public bool IsMoving;

    //wi/lose
    WinLoseCanvas winLose;

    public enum Direction { up , down , right , left };
    public Direction direction;

    // Start is called before the first frame update
    void Start()
    {
        IsMoving = false;
        usedSteps = 0;
        gameManger = FindObjectOfType<GameManger>();
        stepsCounterText.GetComponent<TMP_Text>().text = availableSteps.ToString() ;
        winLose = FindObjectOfType<WinLoseCanvas>();
    }

    public void AddStep()
    {
        if (availableSteps > 0)
        {
            availableSteps--;
            usedSteps++;
            stepsCounterText.GetComponent<TMP_Text>().text = availableSteps.ToString();
        }
        if (availableSteps == 0)
        {
            winLose.Lose();
            Debug.Log("YOU LOST");
        }

        if (availableSteps <= alarmStepsNum)
        {
            stepsCounterText.GetComponent<TMP_Text>().color = UnityEngine.Color.red;
        }

    }

    public void GoalReached()
    {
        availableSteps--;
        usedSteps++;
        stepsCounterText.GetComponent<TMP_Text>().text = availableSteps.ToString();
    }


    public void AddStep2()
    {
        if (availableSteps > 0)
        {
            availableSteps--;
            usedSteps++;
            stepsCounterText.GetComponent<TMP_Text>().text = availableSteps.ToString();
        }
        if (availableSteps == 0)
        {
            winLose.Lose2();
            Debug.Log("YOU LOST");
        }

        if (availableSteps <= alarmStepsNum)
        {
            stepsCounterText.GetComponent<TMP_Text>().color = UnityEngine.Color.red;
        }

    }
}
