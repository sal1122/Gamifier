using UnityEngine;

public class MovePoint : MonoBehaviour
{
    [HideInInspector] public PlayerController myAtom;

    private void Awake()
    {
        myAtom = GetComponentInParent<PlayerController>();
    }

    public void Stop()
    {
        myAtom.stop = true;
    }
}
