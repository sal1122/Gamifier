using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{

    [SerializeField] private AudioClip[] damagefx;
    [SerializeField] private AudioClip[] swipeSfx;
    [SerializeField] private AudioClip[] winningSfx;
    [SerializeField] private AudioClip[] loseSfx;
    [SerializeField] private AudioClip[] explosion;
    [SerializeField] private AudioClip[] tabSfx;
    [SerializeField] private AudioClip[] impactSfx;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    //pay attiention to the times scale claue

    public void PlayDamageSfx()
    {
        if (Time.timeScale > 0)
        {
            gameObject.GetComponent<AudioSource>().PlayOneShot(damagefx[Random.Range(0, damagefx.Length)]);
        }
    }

    public void PlaySwipeSfx()
    {
        if (Time.timeScale > 0)
        {
            gameObject.GetComponent<AudioSource>().PlayOneShot(swipeSfx[Random.Range(0, swipeSfx.Length)]);
        }
    }

    public void PlayPLoseSfx()
    {
        gameObject.GetComponent<AudioSource>().PlayOneShot(loseSfx[Random.Range(0, loseSfx.Length)]);
    }

    public void PlayWinningSfx()
    {
        gameObject.GetComponent<AudioSource>().PlayOneShot(winningSfx[Random.Range(0, winningSfx.Length)]);
    }

    public void PlayExplosionSfx()
    {
        if (Time.timeScale > 0)
        {
            gameObject.GetComponent<AudioSource>().PlayOneShot(explosion[Random.Range(0, explosion.Length)]);
        }
    }

    public void PlayTabSfx()
    {
        if (Time.timeScale > 0)
        {
            gameObject.GetComponent<AudioSource>().PlayOneShot(tabSfx[Random.Range(0, tabSfx.Length)]);
        }
    }

    public void PlayImpactSfx()
    {
        if (Time.timeScale > 0)
        {
            gameObject.GetComponent<AudioSource>().PlayOneShot(impactSfx[Random.Range(0, impactSfx.Length)]);
        }
    }

}
