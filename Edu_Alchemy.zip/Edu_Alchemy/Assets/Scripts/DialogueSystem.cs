﻿using UnityEngine;
using TMPro;

public class DialogueSystem : MonoBehaviour
{
    [SerializeField] [TextArea] public string[] sentances;
    int index;
    [SerializeField] GameObject textBox;
    [SerializeField] TMP_Text textDisplay;

    [HideInInspector] public bool finished;

    void Start()
    {
        textBox.SetActive(true);
        textDisplay.text = sentances[index];
    }

    void Update()
    {
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            if (index < sentances.Length - 1)
            {
                index++;
                textDisplay.text = "";
                textDisplay.text = sentances[index];
            }
            else
            {
                //dialogue is finished
                textDisplay.text = "";
                textBox.SetActive(false);
                finished = true;
            }
        }
    }
}
