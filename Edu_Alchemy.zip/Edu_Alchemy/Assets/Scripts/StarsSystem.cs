using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarsSystem : MonoBehaviour
{
    [SerializeField] int minStepsNum;
    StepsCounterSystem stepsCounterSystem;

    [SerializeField] GameObject[] stars;
    // Start is called before the first frame update
    void Start()
    {
        stepsCounterSystem = FindObjectOfType<StepsCounterSystem>();
        if(stepsCounterSystem.usedSteps <= minStepsNum)
        {
            for (int i = 0; i < stars.Length; i++)
            {
                stars[i].SetActive(true);
            }
        }else if (stepsCounterSystem.usedSteps == minStepsNum + 1)
        {
            for (int i = 0; i < stars.Length -1; i++)
            {
                stars[i].SetActive(true);
            }
        }else if (stepsCounterSystem.usedSteps == minStepsNum + 2)
        {
            for (int i = 0; i < stars.Length - 2; i++)
            {
                stars[i].SetActive(true);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
