using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObsMoveController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Transform movePoint;
    public LayerMask whatStopsMovement;


   [SerializeField] Vector3 moveDirection;
    bool move, spriteMove;

    DialogueSystem ds;
    // Start is called before the first frame update
    void Start()
    {
        movePoint.parent = null;
        ds = FindObjectOfType<DialogueSystem>();
    }

    // Update is called once per frame



    private void Update()
    {
        if (!ds.finished)
            return;
        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, movePoint.position) <= 0.05f)
        {


            if (!Physics2D.OverlapCircle(movePoint.position + moveDirection, .2f, whatStopsMovement))
            {
                movePoint.position += moveDirection;
            }
            else
            {
                moveDirection = -moveDirection;
                movePoint.position += moveDirection;
            }

        }
    }
}
