using System.Collections;
using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField] GameObject otherPortal;
    [SerializeField] GameObject boxCollider;
    bool stopPort;

    StepsCounterSystem stepSystem;
    [SerializeField] LayerMask layer;
    public bool up, down, right, left;

    private void Awake()
    {
        stepSystem = FindObjectOfType<StepsCounterSystem>();
    }

    private void Update()
    {

        Ray();

        if (stepSystem.direction == StepsCounterSystem.Direction.up)
        {
            if (otherPortal.GetComponent<Portal>().up)
            {
                boxCollider.SetActive(true);
            }
            else
            {
                boxCollider.SetActive(false);
            }
        }
        if (stepSystem.direction == StepsCounterSystem.Direction.down)
        {
            if (otherPortal.GetComponent<Portal>().down)
            {
                boxCollider.SetActive(true);
            }
            else
            {
                boxCollider.SetActive(false);
            }
        }
        if (stepSystem.direction == StepsCounterSystem.Direction.right)
        {
            if (otherPortal.GetComponent<Portal>().right)
            {
                boxCollider.SetActive(true);
            }
            else
            {
                boxCollider.SetActive(false);
            }
        }
        if (stepSystem.direction == StepsCounterSystem.Direction.left)
        {
            if (otherPortal.GetComponent<Portal>().left)
            {
                boxCollider.SetActive(true);
            }
            else
            {
                boxCollider.SetActive(false);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (stopPort)
            return;

        if (col.CompareTag("Player"))
        {
            if(col.GetComponent<MovePoint>().myAtom.portPos[0] == null)
            {
                col.GetComponent<MovePoint>().myAtom.portPos[0] = transform;
            }
            else
            {
                col.GetComponent<MovePoint>().myAtom.portPos[1] = transform;
            }
            
            col.transform.position = otherPortal.transform.position;
        }

        if (col.CompareTag("req") || col.CompareTag("nonReq") || col.CompareTag("nonReqC"))
        {
            StartCoroutine(StopPort());
            col.GetComponent<PlayerController>().StartCoroutine(col.GetComponent<PlayerController>().StopTrail(0.299f));
            col.transform.position = otherPortal.transform.position;
            col.GetComponent<PlayerController>().DeleteTemp();
            //col.GetComponent<PlayerController>().portPos = null;
        }
    }

    IEnumerator StopPort()
    {
        otherPortal.GetComponent<Portal>().stopPort = true;
        yield return new WaitForSeconds(1);
        otherPortal.GetComponent<Portal>().stopPort = false;
    }

    void Ray()
    {
        RaycastHit2D right = Physics2D.Raycast(new Vector2(transform.position.x + 0.3f, transform.position.y), transform.right, 1,layer);
        Debug.DrawLine(new Vector2(transform.position.x + 0.3f, transform.position.y), transform.position + transform.right * 1, Color.red);

        RaycastHit2D left = Physics2D.Raycast(new Vector2(transform.position.x - 0.3f, transform.position.y), -transform.right, 1,layer);
        Debug.DrawLine(new Vector2(transform.position.x - 0.3f, transform.position.y), transform.position + -transform.right * 1, Color.red);

        RaycastHit2D up = Physics2D.Raycast(new Vector2(transform.position.x, transform.position.y + 0.3f), transform.up, 1, layer);
        Debug.DrawLine(new Vector2(transform.position.x, transform.position.y + 0.3f), transform.position + transform.up * 1, Color.red);

        RaycastHit2D down = Physics2D.Raycast(new Vector2(transform.position.x, transform.position.y - 0.3f), -transform.up, 1, layer);
        Debug.DrawLine(new Vector2(transform.position.x, transform.position.y - 0.3f), transform.position + -transform.up * 1, Color.red);

        if(right)
        {
            this.right = true;
        }
        else
        {
            this.right = false;
        }

        if (left)
        {
            this.left = true;
        }
        else
        {
            this.left = false;
        }

        if (up)
        {
            this.up = true;
        }
        else
        {
            this.up = false;
        }

        if (down)
        {
            this.down = true;
        }
        else
        {
            this.down = false;
        }
    }
}
