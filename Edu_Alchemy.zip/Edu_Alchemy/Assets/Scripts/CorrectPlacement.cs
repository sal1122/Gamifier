using UnityEngine;

public class CorrectPlacement : MonoBehaviour
{

    [SerializeField] GridLayout grid;
    Vector3Int tilePos;

    void Start()
    {
        tilePos = grid.WorldToCell(transform.position);
        transform.position = tilePos;
    }

}
