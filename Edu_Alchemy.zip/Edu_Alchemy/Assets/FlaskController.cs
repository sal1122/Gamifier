using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlaskController : MonoBehaviour
{
    public int currentAtomsNum;
    public int requiredAtoms;
    // Start is called before the first frame update
    void Start()
    {
        currentAtomsNum = 0;
    }

  
}
