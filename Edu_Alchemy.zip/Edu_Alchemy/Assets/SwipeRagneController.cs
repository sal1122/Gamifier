using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SwipeRagneController : MonoBehaviour
{
    [SerializeField] GameObject atom;
    public GameObject swipeRangeText;
    // Start is called before the first frame update
    void Start()
    {
        swipeRangeText.GetComponent<TMP_Text>().text = atom.GetComponent<PlayerController>().swipeRange.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void IncreseSwipeRange()
    {
        atom.GetComponent<PlayerController>().swipeRange += 5f;
        swipeRangeText.GetComponent<TMP_Text>().text = atom.GetComponent<PlayerController>().swipeRange.ToString();
    }

    public void DecreseSwipeRange()
    {
        atom.GetComponent<PlayerController>().swipeRange -= 5f;
        swipeRangeText.GetComponent<TMP_Text>().text = atom.GetComponent<PlayerController>().swipeRange.ToString();
    }
}
