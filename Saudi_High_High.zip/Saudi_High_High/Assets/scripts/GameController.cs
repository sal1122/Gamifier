using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    [SerializeField] GameObject gameOverPanel;

    WinLoseScript WLvar;
    public Animator anim;

    bool loseOnce;
    private void Awake()
    {
        LeanTween.reset();
        //Time.timeScale = 1;
    }

    // Start is called before the first frame update
    void Start()
    {
        loseOnce = false;
        WLvar = FindObjectOfType<WinLoseScript>();
    }


    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag("platform"))
        {
            Destroy(col.gameObject);
        }

        if (col.CompareTag("Player"))
        {
            
           
           if(loseOnce == false)
            {
                PerformLose();
            }

        }
    }

    void PerformLose()
    {
        
         loseOnce = true;
        //WLvar.Lose();
        Time.timeScale = 0;
        gameOverPanel.SetActive(true);
        //LoadLevel();
    }

    IEnumerator LoadLevel()
    {
        //Time.timeScale = 0;
        anim.SetTrigger("Start");
        yield return new WaitForSeconds(0.7f);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
