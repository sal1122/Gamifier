using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseBtn : MonoBehaviour
{
    [SerializeField] Button[] buttons;
    public Transform box;
    public CanvasGroup background;
    [SerializeField] float delayTime;

    //BG music conroller;
    //BGVolController bGVolController;

    private void Awake()
    {
        LeanTween.reset();
    }

    private void Start()
    {
        //bGVolController = FindObjectOfType<BGVolController>();
    }

    private void OnEnable()
    {
        background.alpha = 0;
        background.LeanAlpha(1, 0.5f);

        box.localPosition = new Vector2(0, -Screen.height);
        box.LeanMoveLocalY(0, 1.5f).setEaseOutExpo().delay = 0.1f;
        StartCoroutine(stopTimeDelay());
    }


    public void CloseDialog()
    {
        Time.timeScale = 1;
        background.LeanAlpha(0, 0.5f);
        box.LeanMoveLocalY(-Screen.height, 0.5f).setIgnoreTimeScale(true).setEaseInExpo().setOnComplete(OnComplete);
    }

    //to make sure this is only used in stages button in pause panel
    public void CloseDialogForPausePanel()
    {
        Time.timeScale = 1;
        background.LeanAlpha(0, 0.5f);
        //bGVolController.StartFadeIn();
        box.LeanMoveLocalY(-Screen.height, 0.5f).setIgnoreTimeScale(true).setEaseInExpo().setOnComplete(OnComplete);
    }

    void OnComplete()
    {
        gameObject.SetActive(false);
    }

    IEnumerator stopTimeDelay()
    {
        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = false;
        }
        yield return new WaitForSeconds(delayTime);
        Time.timeScale = 0;
        for (int i = 0; i < buttons.Length; i++)
        {
            buttons[i].interactable = true;
        }
    }
}
