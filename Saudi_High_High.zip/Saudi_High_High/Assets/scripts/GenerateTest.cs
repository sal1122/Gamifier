using UnityEngine;

public class GenerateTest : MonoBehaviour
{
    [SerializeField] GameObject player, platform, coin;
    [SerializeField] float yPos,increaseRate,maxDis;

    //the places where spawning happens
    [SerializeField]Transform[] spawnerPoints;
    int randomSpawnPoint;

    //to controle coins spawning 
    bool generateCoins;
    private void Start()
    {
        generateCoins = false;
        InvokeRepeating("generateCoinsTimer",0, 5f);
        InvokeRepeating("Generate", 0, 0.5f);
    }

    void Generate()
    {
        if(Vector2.Distance(player.transform.position, transform.position) >= maxDis)
            return;
        randomSpawnPoint = Random.Range(0, spawnerPoints.Length);
        Instantiate(platform, new Vector2(spawnerPoints[randomSpawnPoint].position.x, transform.position.y), Quaternion.identity);

        if (generateCoins)
        {
            generateCoins = false;
            randomSpawnPoint = Random.Range(0, spawnerPoints.Length);
            Instantiate(coin, new Vector2(spawnerPoints[randomSpawnPoint].position.x, transform.position.y +5f), Quaternion.identity);
        }

        transform.position = new Vector2(transform.position.x, yPos);
        yPos += increaseRate;

       
    }

    void generateCoinsTimer()
    {
        generateCoins = true;
    }
}
