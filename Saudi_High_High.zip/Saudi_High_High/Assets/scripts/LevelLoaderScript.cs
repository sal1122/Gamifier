using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoaderScript : MonoBehaviour
{
    public Animator anim;

    //private void Start()
    //{
    //    Time.timeScale = 1;
    //}

    public void LoadNextLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex + 1));
    }

    public void LoadPreviousLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex - 1));
    }

    public void LoadSameLevel()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex));
    }

    IEnumerator LoadLevel(int levelIndex)
    {
       // Time.timeScale = 1; //suppose to be 0 but it is not working, only work when it is 1
        anim.SetTrigger("Start");
        yield return new WaitForSecondsRealtime(0.7f);
        //StartCoroutine(timy(levelIndex));
        Time.timeScale = 1;
        SceneManager.LoadScene(levelIndex);
    }

    //IEnumerator timy(int levelIndex)
    //{
    //    //anim.SetTrigger("Start");
    //    yield return new WaitForSeconds(0.2f);
    //    Time.timeScale = 1; //was 1
    //    SceneManager.LoadScene(levelIndex);
    //}

    public void QuitGame()
    {
        Application.Quit();
    }
}
