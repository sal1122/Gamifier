using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    ScoreCounter scoreCounter;
    SfxManager sfxManager;
   // Start is called before the first frame update

   [SerializeField] GameObject partical;
    void Start()
    {
        scoreCounter = FindObjectOfType<ScoreCounter>();
        sfxManager = FindObjectOfType<SfxManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("collect"))
        {
            sfxManager.PlaySfx();
            scoreCounter.updateScore();
            Instantiate(partical, new Vector3(transform.position.x, transform.position.y  -0.3f), Quaternion.EulerRotation(-90, 0, 0));
            Destroy(gameObject);
        }
    }
}
