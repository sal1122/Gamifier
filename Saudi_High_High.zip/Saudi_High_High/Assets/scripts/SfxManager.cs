using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SfxManager : MonoBehaviour
{
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PlaySfx()
    {
        float sfxPitch;
        sfxPitch = Random.Range(0.9f, 1.3f);
        GetComponent<AudioSource>().pitch = sfxPitch;
        GetComponent<AudioSource>().Play();
    }
}
