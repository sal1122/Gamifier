using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rb;
    [SerializeField] float moveInput;
    [SerializeField] float speed,jumpForce;
    Animator animator;
    SpriteRenderer sprite;

    //partical effect
    [SerializeField] GameObject dustPartical;
    bool playParticalOnce;
    
    private void Start()
    {
        playParticalOnce = false;
        animator = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        // locate the mouse position in the screen
        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // as long as the player press the button change moveInput(to left or right depends on mouse position)
        if (Input.GetKey(KeyCode.Mouse0))
        {
            if(mousePos.x >= 0)
            {
                moveInput = 1;
                transform.eulerAngles = new Vector3(0, 180, 0);
            }
            else
            {
                moveInput = -1;
                transform.eulerAngles = new Vector3(0, 0, 0);
            }
        }

        // reset moveInput when the player not pressing any button to make the cube stop
        if (Input.GetKeyUp(KeyCode.Mouse0))
        {
            moveInput = 0;
        }

        //animation
        if(rb.velocity.y > 0.01)
        {
            animator.SetBool("IsJumping", true);
            if (playParticalOnce == false) 
            {
                playParticalOnce = true;
                Instantiate(dustPartical, new Vector3(transform.position.x, transform.position.y +(-0.70f),-0.3f), Quaternion.EulerRotation(-90,0,0));
            }
            
        }
        else
        {
            animator.SetBool("IsJumping", false);
            playParticalOnce = false;
        }

        if(rb.velocity.y == 0)
        {
           
        }
        ////fliping sprite for x axis
        //if(rb.velocity.x > 0.01)
        //{
        //    sprite.flipX = true;
        //}
        //else
        //{
        //    sprite.flipX = false;
        //}
    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        // detect ground
        if (col.gameObject.layer == (6))
        {
            if(rb.velocity.y <= 0)
            {
                rb.velocity = Vector2.up * jumpForce;
            }
        }
    }



    
}
