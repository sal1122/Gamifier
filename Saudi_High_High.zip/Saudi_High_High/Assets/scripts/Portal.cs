using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField] GameObject otherPortal;
    [HideInInspector] public bool stopPort;

    float newPos;

    [SerializeField] bool right;

    private void Start()
    {
        Vector3 camPos = Camera.main.transform.position;

        if (right)
        {
            newPos = Vector2.Distance(Camera.main.ScreenToWorldPoint(new Vector2(0, 0)), Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, 0))) * 0.7f;
        }
        else
        {
            newPos = Vector2.Distance(Camera.main.ScreenToWorldPoint(new Vector2(0, 0)), Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, 0))) * -0.7f;
        }
        

        transform.position = new Vector2(newPos, transform.position.y);
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        //detect the player
        if(col.gameObject.layer == 3 /*&& !stopPort*/)
        {
            otherPortal.SetActive(false);
            Invoke("TurnOn", 0.2f);
            //stopPort = true;
            //otherPortal.GetComponent<Portal>().stopPort = true;
            col.transform.position = new Vector2(otherPortal.transform.position.x,col.transform.position.y);
        }
    }

    //private void OnTriggerExit2D(Collider2D col)
    //{
    //    if (col.gameObject.layer == 3)
    //    {
    //        otherPortal.GetComponent<Portal>().stopPort = false;
    //    }
    //}

    void TurnOn()
    {
        otherPortal.SetActive(true);
    }
}
