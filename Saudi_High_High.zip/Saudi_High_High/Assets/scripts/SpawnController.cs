using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnController : MonoBehaviour
{
   
    //the places where spawning happens
    public Transform[] spawnerPoints;

    //objects to spwan
    public GameObject[] objsToSpawn;

    //to randomize the spawning operation
    int randomSpawnPoint, rendomObj;

    // bool variable to controle the opreation
    public static bool spawnAllowed;

    //to randomize the altitude of the spawned objects
    public float minYshifting;
    public float maxYshifting;
    public float shiftTime;


    // Start is called before the first frame update
    void Start()
    {
        spawnAllowed = true;
    }



    public void SpawningObjects()
    {
        if (spawnAllowed)
        {
            randomSpawnPoint = Random.Range(0, spawnerPoints.Length);

            rendomObj = Random.Range(0, objsToSpawn.Length);

            Instantiate(objsToSpawn[rendomObj], new Vector2(spawnerPoints[randomSpawnPoint].position.x,
                spawnerPoints[randomSpawnPoint].position.y+ Random.Range(minYshifting,maxYshifting)),
                Quaternion.identity);
        }
    }

    
}
