using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinLoseScript : MonoBehaviour
{
    // lose win contoller
    public GameObject winPanel;
    public GameObject losePanel;
    public float delayTime;
    public float delayTime2;

    public Transform boxW;
    public Transform boxL;
    //public CanvasGroup background;

    public Animator anim;

    //aduio setting
    //AudioManager2 audioManager;
    //BG music conroller;
    //BGVolController bGVolController;

    //save system 
    //UnlockLevels unlockLevels;

    //StartBtn SBtnV;

    //int winORlose;
    private void Awake()
    {
        LeanTween.reset();
    }

    // Start is called before the first frame update
    void Start()
    {
        //audioManager = FindObjectOfType<AudioManager2>();
        //unlockLevels = FindObjectOfType<UnlockLevels>();
        //bGVolController = FindObjectOfType<BGVolController>();
        boxW.localScale = Vector2.zero;
        boxL.localScale = Vector2.zero;
    }

    //private void OnEnable()
    //{
    //    background.alpha = 0;
    //    background.LeanAlpha(1, 0.5f);
    //    Debug.Log("hello world");
    //}

    public void Win()
    {
        //unlockLevels.Pass();
        StartCoroutine(Winning());
    }

    public void Lose()
    {
        StartCoroutine(Losing());
    }

    IEnumerator Winning()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime);

        //audioManager.Play("Win");
        winPanel.SetActive(true);
        Time.timeScale = 0;

        Debug.Log("Wining method: before");
        boxW.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        Debug.Log("Wining method: after");
        yield return new WaitForSecondsRealtime(1f);
        //bGVolController.StartFadeIn();
    }

    IEnumerator Losing()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime);

        //audioManager.Play("Lose");
        losePanel.SetActive(true);
        Time.timeScale = 0;
        Debug.Log("Losing method: before");
        boxL.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        Debug.Log("Losing method: after leentween");
        yield return new WaitForSecondsRealtime(1f);
        //bGVolController.StartFadeIn();
    }

    public void CloseDialog()
    {
        boxL.LeanScale(Vector2.zero, 0.4f).setIgnoreTimeScale(true).setEaseInBack().setOnComplete(OnComplete);
        boxW.LeanScale(Vector2.zero, 0.4f).setIgnoreTimeScale(true).setEaseInBack().setOnComplete(OnComplete);
    }

    void OnComplete()
    {
        StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex));
    }

    IEnumerator LoadLevel(int levelIndex)
    {
        Time.timeScale = 1;
        anim.SetTrigger("Start");
        yield return new WaitForSeconds(0.7f);
        SceneManager.LoadScene(levelIndex);
    }

    public void Lose2()
    {
        StartCoroutine(Losing2());
    }

    IEnumerator Losing2()
    {
        //wait for the effect to be done
        yield return new WaitForSeconds(delayTime2);

        //audioManager.Play("Lose");
        losePanel.SetActive(true);
        Time.timeScale = 0;
        Debug.Log("Losing method: before");
        boxL.LeanScale(Vector2.one, 0.7f).setIgnoreTimeScale(true).setEaseOutBack().delay = 0.3f;
        Debug.Log("Losing method: after leentween");
        yield return new WaitForSecondsRealtime(1f);
        //bGVolController.StartFadeIn();
    }
}
